<?php

namespace steellgold\oneblock\utils;

interface RankIds {

	const VISITOR = 0;
	const MEMBER = 1;
	const OFFICIER = 2;
	const LEADER = 3;
}